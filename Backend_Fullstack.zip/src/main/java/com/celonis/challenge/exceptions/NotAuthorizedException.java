package com.celonis.challenge.exceptions;

public class NotAuthorizedException extends RuntimeException {
}
