export const GENERATE_SAMPLE_PROJECT_NAME =
  'This task generates the sample project that should be used to finis challenge 2 and 3.';

export const COUNT_TASK_NAME =
  'This task counts from given input X to given input Y.';

export const CHECK_PROGRESS_EVERY_SECONDS = 3000;
