package com.celonis.challenge.exceptions;

public class NotFoundException extends RuntimeException {
}
