export class StatusResponse {
  status!: number;

  constructor() {}
}
