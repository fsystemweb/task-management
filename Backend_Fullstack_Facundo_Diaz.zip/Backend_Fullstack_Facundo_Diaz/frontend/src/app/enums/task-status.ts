export enum TaskStatus {
  NEW = 'NEW',
  RUNNING = 'RUNNING',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED',
}
