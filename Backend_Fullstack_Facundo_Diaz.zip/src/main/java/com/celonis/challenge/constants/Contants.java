package com.celonis.challenge.constants;

public class Contants {
    public static final String CELONIS_HEADER_KEY = "Celonis-Auth";
    public static final String CELONIS_HEADER_VALUE = "totally_secret";
    public static final String PROJECT_FILENAME = "challenge.zip";
}
