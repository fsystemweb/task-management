package com.celonis.challenge.model;

public enum EnumStatusTask {
    NEW,
    RUNNING,
    CANCELLED,
    COMPLETED
}
