package com.celonis.challenge.model;

public enum EnumTypeTask {
    GENERATE_SAMPLE_PROJECT, COUNT_TASK
}
